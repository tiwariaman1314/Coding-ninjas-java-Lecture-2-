

import java.util.*;
public class Lecture2
{
    
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        
    }
    
    // public static void main(String [] args){
    //     Scanner sc=new Scanner(System.in);
    //     String x=sc.next();
    //     String y=sc.nextLine();
    //     char  ch = sc.next().charAt(0);
        
    //     System.out.println(x);
    //     System.out.println(y);
    //     System.out.println(ch);
        
    // }
    
    // public static void main(String [] args){
    //     Scanner sc=new Scanner(System.in);
    //     int x = sc.nextInt();
    //     System.out.println(x);
    //     // sc.nextDouble()
    //     // sc.nextLong()
        
    // }
    
    
    // public static void main(String [] args){
    //     int a=10;
    //     int b=3;
    //     int c=a%b;
    //     double d=a/5;
    //     int e=3+2/5;
        
    //     System.out.println(c);
    //     System.out.println(d);
    //     System.out.println(e);
    // }
    
    // public static void main(String [] args){
    //     byte b=11;
    //     short s=15;
    //     int i=10;
    //     long l=117;
    //     double d=1.75;
    //     float f=1.25f;
    //     char c='a';
    //     boolean bool=true;
        
    // }
    
    // public static void main(String [] args){
    //     int a=5;
    //     int b=10;
    //     int c=a+b;
    //     System.out.println(c);
    // }
 
    
// 	public static void main(String[] args) {
// 		System.out.println("Hello World");
// 		System.out.println("AMAN TIWARI");
// 	}
}
